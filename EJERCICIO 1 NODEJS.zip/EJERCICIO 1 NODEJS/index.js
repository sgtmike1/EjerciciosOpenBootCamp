//mensaje incial
console.log("Hola, este es mi primer ejercicio con Node en el mejor Bootcamp de programación del mundo");
//agradecimiento
console.log("Gracias por estos fantasticos cursos");
//saludo
console.log("Con este mensaje me despido.");
