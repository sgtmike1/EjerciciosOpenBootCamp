var human = { //Asigne human a var dado que obviamente la que mi estado de "human" no cambiaria.
    name: "Michael Olivera", //string
    nickName: "Mike",
    age: 30 + " Años",  //Number + string
    dateBirth: "Ha nacido el: "  + new Date(1993, 1, 10) + " Por la tarde", //string + date
    height: 186 + " CM",// string + number 
    isDeveloper: true, //boolean
    isShort: false, //boolean
    hasBeard: true, // boolean
    likesPcgames: true, // Otro boolean
    enjoysOBootcamp: "Muchisimo, es el mejor lugar para aprender programacion", //Otro string
    libroFavorito: {
        nombreLibro: "The Lord Of The Rings: The Two towers",
        authorName: "J. R. R. Tolkien",
        releaseDate: "El libro fue publicado el:" + new Date(1954, 12, 11),
        informacionLibro: "Mas informacion acerca del libro en: https://en.wikipedia.org/wiki/The_Two_Towers",
}
}
console.log(human)